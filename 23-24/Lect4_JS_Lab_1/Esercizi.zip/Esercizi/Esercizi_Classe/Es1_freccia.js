let onclick_fn = () => alert('hello world');
//let onclick_fn = () => (alert('hello world'));
//let onclick_fn = () => {alert('hello world');}



