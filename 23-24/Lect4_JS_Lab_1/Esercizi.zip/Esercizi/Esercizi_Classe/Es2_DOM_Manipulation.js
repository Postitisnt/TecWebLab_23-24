function onclick_fn(){
    var inner_html = document.getElementsByTagName('h1')[0].innerHTML;
    var para1 = document.getElementById('para1');
    para1.textContent = inner_html;
}


